# hunit

Upload a document → hunit removes watermarks, fixes grammar and structure, and rewrites it in a natural, human voice. Users sign up / log in and every result is saved to their history.

## Run locally
```bash
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml   # add your Anthropic API key
streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Push this folder to a new GitHub repo.
2. Go to share.streamlit.io → **New app** → pick the repo, branch `main`, main file `app.py`.
3. **Advanced settings → Secrets**: paste the contents of `.streamlit/secrets.toml.example` with your real key.
4. Deploy.

## Important notes
- **History persistence:** Streamlit Cloud's disk is ephemeral. The SQLite file (`hunit.db`) is wiped when the app reboots/redeploys. For permanent history, swap the DB layer for a hosted database (Supabase/Postgres, Neon, etc.).
- **Watermarks:** handles PDF (watermark artifacts, watermark annotations, repeated diagonal/faint text, plus any text you specify) and DOCX (header/footer watermark shapes, plus text you specify). Image-based watermarks baked into scanned pages can't be removed reliably. Use it only on documents you own or have the right to edit.
- Supported uploads: PDF, DOCX, TXT, MD.
